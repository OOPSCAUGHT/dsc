import struct
import subprocess
import tempfile
import os
import re
from typing import Dict, List, Tuple, Optional, Callable
from dataclasses import dataclass
from pathlib import Path
import logging
import asyncio

logger = logging.getLogger(__name__)

@dataclass
class OffsetResult:
    function_name: str
    expected_offset: int
    found_offset: Optional[int]
    confidence_score: float
    validation_method: str
    pattern_matches: List[str]

class DiscordVoiceOffsetFinder:
    """
    Advanced offset finder for discord_voice.node files.
    Uses multiple detection methods for high confidence results.
    """
    
    # Expected function signatures and patterns from the provided list
    EXPECTED_OFFSETS = {
        'CreateAudioFrameStereoInstruction': 0xAD794,
        'AudioEncoderOpusConfigSetChannelsInstruction': 0x302EA8,
        'MonoDownmixerInstructions': 0x95B23,
        'HighPassFilter_Process': 0x4A5022,
        'EmulateStereoSuccess': 0x497504,
        'EmulateBitrateModified': 0x497762,
        'Emulate48Khz': 0x49761B,
        'HighpassCutoffFilter': 0x8B4370,
        'DcReject': 0x8B4550,
        'downmix_func': 0x8B0BB0,
        'AudioEncoderOpusConfig_IsOk': 0x30310C,
        'AudioEncoderOpusImpl_EncodeImpl_Jump': 0x4998BA,
        'AudioEncoderOpusImpl_EncodeImpl_Shellcode': 0x499A2F,
        'CompressionInstruction': 0x4A0C28,
        'AGCConfigFunction': 0x4A6F84,
        'InputClippingInstruction': 0x04A70F2,
        'AGCDigitalGain': 0x664584,
        'AGCClippingAdjustmentInstruction': 0x4A66BE,
        'AGCClippingAdjustmentInstruction2': 0x663698,
        'EchoCancellationInstruction': 0x8F5E24,
        'Aec3DelayOverTimeInstruction': 0x336304,
        'EchoCancellerJitterInstruction': 0x4ECC78,
        'GainControllerAnalogInstruction': 0x3167A2,
        'AudioProcessing_ProcessStream_AudioFrame': 0x319C60,
        'AudioProcessing_ProcessStream_StreamConfig': 0x318630,
        'NetEqDelayManager': 0xD8F730,
        'AudioMixerImpl_Mix': 0x2124E0,
        'NoiseCancellerProcessInstructions': 0x95CB0,
        'StationaryEstimator': 0xB55044,
        'NoiseCongestion': 0x4FD1F4,
        'ServerSideEq': 0x8FB4CE,
        'NoiseCanceller': 0x969C0,
        'setRemoteUserCanHavePriority': 0x167A4,
        'MultiSamplePCM': 0x883A0,
        'SampleSourceAudio': 0x89980,
        'WebRTC_PCM': 0x49AAC8,
        'MaxBitratePatch': 0x3A6D90,
        'Limiter_Process': 0x311DFE,
        'DuckingProcess': 0x1C740,
        'AudioProc': 0x2080A3,
        'AudioProcessingApplyConfig': 0x317E00,
        'AudioProcessingInstruction': 0x237694,
        'AudioProcessingInstruction2': 0x315D70,
        'CompressionInstruction2': 0x4A5E04,
        'RegisterAudioCallback': 0x20D100,
        'StartRecording': 0x20CE50,
        'SendProcessedData': 0x31C748,
        'SendProcessedData2': 0x31C920,
        'AudioProcessingImpl': 0x3142C8,
        'RecordedDataIsAvailable': 0x303E70,
        'NoiseBuffer': 0xA805D0,
        'ComfortNoise': 0xB6069E,
        'ChannelMixerInstructions': 0x4A15E0,
        'FrameCombiner': 0x20D948,
        'AudioMixerHighestCount': 0x212A0C,
        'WAVEFILEAUDIOPCM': 0x8A7C0,
        'EnableBuiltInAGC': 0x20D490,
        'EnableBuiltInAGC2': 0x311B50,
        'EnableBuiltInNS': 0x20D630,
        'EnableBuiltInNS2': 0x311C30,
        'EnableBuiltInAEC': 0x20D2F0,
        'EnableBuiltInAEC2': 0x311A70,
        'input_volume_controller': 0x66357E,
        'input_volume_controller2': 0x66373E,
        'clipping_predictor': 0x664B88,
        'render_delay_buffer': 0x6A7360,
        'render_delay_buffer2': 0x6A7870,
        'AudioProcessingPreProcessor': 0x314516,
        'TransientSuppressor': 0x316B0A,
        'GainController2Config': 0x317E00,
        'runtimeProcessing': 0x3183D0,
        'linearAECOutput': 0x31AC70,
        'set_stream_analog_level': 0x31ADE0,
        'AGCVolumeCallbacks': 0x4A6478,
        'AGCVolumeCallbackLimiter': 0x4A67BA,
        'BandwidthLimiter': 0xD8B6CE,
        'ReverbProcess': 0xD8F4D0,
        'CoarseFilterUpdateGain': 0xB5191A,
        'MonoAGC_MaxLevel': 0x664110,
        'TargetAudioBitrateConstraints': 0x33015A,
        'clipped_level_min': 0x313674,
        'HPFixedInput': 0x8BDA84,
        'fixed_digital': 0x4A3816,
        'SetNoiseCancellationOverride': 0x96840,
        'matching_filter': 0x8EE00C,
        'percentileHardclip': 0x4FE770,
        'loss_threshold': 0x8D1374,
        'max_bitrate_bps': 0x4D93D0,
        'WebRTCOpusConfigChannelAndFEC': 0x65DCF6,
        'WebRTCFrequencyResponse48khz': 0x4FE1C2,
        'FecBitrateSentInBps': 0x4C4678,
        'MediaSideFilterEq': 0x1425A0,
        'SidechainCompressorInstruction': 0xEFBB0,
        'WebRTC_SetEnableFec': 0x49842A,
        'controller_manager_config': 0x65DCF6,
        'frame_length_controller': 0x8C3E24,
        'ServerSideEqController': 0x8F7080,
        'SetDuckingPreference': 0x17C20,
        'SetRemoteUserCanHavePriorityProcessInstruction': 0x32580,
        'SuppressionGain_GainParameters': 0x8F22B8,
        'BackgroundNoiseUpdateInstruction': 0xB5C390,
        'WebRtcIlbcfix_DoThePlc': 0xB38CB0,
        'WebRTCAec3MinErleDuringOnsetsKillSwitch': 0xD8C5F0,
        'AudioEncoderHarmonicFrameRate': 0x4F071E,
        'DiscordConfigAudioMuxer': 0x131870,
        'Discord_FrameLengthMin': 0x689EB0,
        'Emulate_48kHz_960ms': 0x8A490,
        'Resampler_48kHz': 0xB3E2C2,
        'SinewaveEmulator': 0x86110,
        'FreqIsStrange': 0x457E20,
        'SinewaveAmplification': 0x89BD0,
        'CeltEncoder_IsNanHardclip': 0xB1F54D,
        'CeltEncoder_IsNanNormalization': 0xB20194,
        'CeltEncoder_IsNanTempBuffer': 0xB2016E,
        'WebRTC_Audio_2ndAgcMinMicLevelExperiment': 0x4A68CC,
        'WebRTC_Audio_AgcClippingAdjustmentAllowed': 0x4A66BE,
        'WebRTC_Audio_AgcClippingAdjustmentAllowed2': 0x663698,
        'WebRTC_Thread': 0x2283EE,
        'DiscordVoiceFilter': 0x109EB0,
        'discord_voice_filters_node': 0x10D1E0,
        'loop_filter_data': 0x6B6130,
        'filter_graph': 0x1425A0,
        'MediaPipeGraph': 0x16DFA0,
        'FilterSettings': 0x144430,
        'VoiceFilterCreate': 0x109C00,
        'StereoPlayoutIsntSupported': 0x20BBF0,
        'EmulateMono48kHz': 0x6249B0,
        'OpusHardclip': 0x8B3C20,
        'OpusHardclip2': 0x8A3C65,
        'DiscordAudioLevel': 0x334E45,
        'DiscordPostProcessingBufferAllocation': 0x952D10,
        'setRemoteUserCanHavePriority2': 0x015A70,
        'ducking': 0x005920,
        'red_payload_splitter': 0xB61E20,
        'nack_tracker': 0xB5CE1C,
        'delay_manager': 0xD8FAF,
        'packet_buffer': 0xB5A598,
        'dtmf_buffer': 0xB59D4A,
        'neteq_impl': 0x8F6C5C,
        'comfort_noise': 0xB6069E,
        'decoder_database': 0xB59690,
        'decision_logic': 0xB55BEC,
        'ApplySidechainCompressionSettings': 0x0AEE00,
        'SetSidechainCompression': 0x0AED70,
        'reinit_after_expands': 0x0B1D10,
        'WebRTC_Audio_Allocation': 0x32D576,
        'WebRTC_Audio_OpusBitrateMultipliers': 0x497C58,
        'WebRTC_Audio_OpusAvoidNoisePumpingDuringDtx': 0x65AD34,
        'WebRTC_Audio_OpusSetSignalVoiceWithDtx': 0x65B367,
        'OpusPlcUsePrevDecodedSamples': 0x65B83E,
        'Red_For_Opus': 0x4C2E94,
        'AlrProbing': 0x36FCFA,
    }

    def __init__(self):
        self.results: List[OffsetResult] = []

    async def analyze_file(self, file_path: str) -> List[OffsetResult]:
        """
        Main analysis function that combines multiple detection methods.
        """
        logger.info(f"Starting analysis of {file_path}")
        
        # Reset results
        self.results = []
        
        # Get file info
        file_info = await self._get_file_info(file_path)
        logger.info(f"File info: {file_info}")
        
        # Method 1: Disassembly analysis
        disasm_results = await self._analyze_with_objdump(file_path)
        
        # Method 2: Binary pattern matching
        pattern_results = await self._analyze_with_pattern_matching(file_path)
        
        # Method 3: String analysis (for function names/symbols)
        string_results = await self._analyze_strings(file_path)
        
        # Combine and validate results
        combined_results = await self._combine_and_validate_results(
            disasm_results, pattern_results, string_results
        )
        
        self.results = combined_results
        logger.info(f"Analysis complete. Found {len(self.results)} results")
        
        return self.results

    async def analyze_file_with_progress(self, file_path: str, progress_callback: Callable) -> List[OffsetResult]:
        """
        Main analysis function with progress tracking.
        """
        logger.info(f"Starting analysis with progress tracking of {file_path}")
        
        # Reset results
        self.results = []
        
        # Get file info
        file_info = await self._get_file_info(file_path)
        logger.info(f"File info: {file_info}")
        
        total_functions = len(self.EXPECTED_OFFSETS)
        current_function = 0
        
        # Method 1: Disassembly analysis
        await progress_callback(current_function, total_functions, "Starting objdump analysis...")
        disasm_results = await self._analyze_with_objdump(file_path)
        
        # Method 2: Binary pattern matching
        current_function += 10
        await progress_callback(current_function, total_functions, "Running binary pattern analysis...")
        pattern_results = await self._analyze_with_pattern_matching(file_path)
        
        # Method 3: String analysis
        current_function += 10
        await progress_callback(current_function, total_functions, "Analyzing strings...")
        string_results = await self._analyze_strings(file_path)
        
        # Process each function individually with progress updates
        current_function = 20
        await progress_callback(current_function, total_functions, "Processing function signatures...")
        
        # Combine and validate results with individual function progress
        combined_results = await self._combine_and_validate_results_with_progress(
            disasm_results, pattern_results, string_results, progress_callback
        )
        
        self.results = combined_results
        logger.info(f"Analysis complete. Found {len(self.results)} results")
        
        # Final progress update
        await progress_callback(total_functions, total_functions, "Analysis complete!")
        
        return self.results

    async def _get_file_info(self, file_path: str) -> Dict:
        """Get basic file information."""
        try:
            file_stat = os.stat(file_path)
            
            # Try to use file command if available
            file_type = 'Unknown'
            is_32bit = False
            
            try:
                result = subprocess.run(['file', file_path], capture_output=True, text=True, timeout=5)
                if result.returncode == 0:
                    file_type = result.stdout.strip()
                    is_32bit = '32-bit' in result.stdout
            except (subprocess.TimeoutExpired, FileNotFoundError, subprocess.SubprocessError):
                # Fall back to basic binary detection
                with open(file_path, 'rb') as f:
                    header = f.read(16)
                    if header.startswith(b'\x7fELF'):
                        file_type = 'ELF binary'
                        # Check ELF class byte (5th byte): 1=32-bit, 2=64-bit
                        if len(header) > 4:
                            is_32bit = header[4] == 1
                    elif header.startswith(b'MZ'):
                        file_type = 'PE executable'
                        is_32bit = True  # Assume 32-bit for PE files
                    elif b'.node' in file_path.encode() or len(header) > 0:
                        file_type = 'Binary file'
                        is_32bit = True  # Assume 32-bit for .node files
            
            return {
                'size': file_stat.st_size,
                'file_type': file_type,
                'is_32bit': is_32bit
            }
        except Exception as e:
            logger.error(f"Error getting file info: {e}")
            return {'size': 0, 'file_type': 'Unknown', 'is_32bit': False}

    async def _analyze_with_objdump(self, file_path: str) -> Dict[str, List[int]]:
        """Analyze using objdump disassembly."""
        logger.info("Running objdump analysis...")
        function_offsets = {}
        
        try:
            # Try different objdump strategies for .node files
            objdump_commands = [
                ['objdump', '-d', file_path],
                ['objdump', '-D', file_path],  # Disassemble all sections
                ['objdump', '-x', file_path],  # All headers
            ]
            
            objdump_output = ""
            
            for cmd in objdump_commands:
                try:
                    result = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
                    if result.returncode == 0 and result.stdout.strip():
                        objdump_output = result.stdout
                        logger.info(f"Successfully ran: {' '.join(cmd)}")
                        break
                    else:
                        logger.warning(f"Command failed: {' '.join(cmd)} - {result.stderr}")
                except subprocess.TimeoutExpired:
                    logger.warning(f"Command timed out: {' '.join(cmd)}")
                    continue
                except Exception as e:
                    logger.warning(f"Command error: {' '.join(cmd)} - {e}")
                    continue
            
            if not objdump_output:
                logger.warning("All objdump commands failed, trying alternative analysis")
                return await self._analyze_binary_structure(file_path)
            
            # Parse objdump output for function patterns
            lines = objdump_output.split('\n')
            current_offset = None
            
            for line in lines:
                # Look for offset patterns (address:)
                offset_match = re.search(r'^\s*([0-9a-f]+):', line)
                if offset_match:
                    current_offset = int(offset_match.group(1), 16)
                
                # Look for function-specific instruction patterns
                if current_offset:
                    # Look for common WebRTC/audio processing patterns
                    if any(pattern in line.lower() for pattern in [
                        'opus', 'audio', 'webrtc', 'agc', 'echo', 'noise', 'discord'
                    ]):
                        # Try to match with expected functions
                        for func_name in self.EXPECTED_OFFSETS.keys():
                            if self._matches_function_pattern(line, func_name):
                                if func_name not in function_offsets:
                                    function_offsets[func_name] = []
                                function_offsets[func_name].append(current_offset)
            
        except Exception as e:
            logger.error(f"Error in objdump analysis: {e}")
        
        return function_offsets

    async def _analyze_binary_structure(self, file_path: str) -> Dict[str, List[int]]:
        """Fallback binary structure analysis when objdump fails."""
        logger.info("Running fallback binary structure analysis...")
        function_offsets = {}
        
        try:
            with open(file_path, 'rb') as f:
                binary_data = f.read()
            
            # Look for common binary patterns that might indicate functions
            patterns = {
                'function_prologue': [b'\x55\x89\xe5', b'\x55\x8b\xec'],  # Common x86 function prologues
                'call_instructions': [b'\xe8', b'\xff\x15'],  # CALL instructions
                'string_refs': [b'opus', b'audio', b'webrtc', b'discord'],  # Relevant strings
            }
            
            for pattern_name, pattern_list in patterns.items():
                for pattern in pattern_list:
                    offsets = self._find_binary_pattern(binary_data, pattern)
                    for offset in offsets:
                        closest_func = self._find_closest_function(offset)
                        if closest_func:
                            if closest_func not in function_offsets:
                                function_offsets[closest_func] = []
                            function_offsets[closest_func].append(offset)
        
        except Exception as e:
            logger.error(f"Error in binary structure analysis: {e}")
        
        return function_offsets

    async def _analyze_with_pattern_matching(self, file_path: str) -> Dict[str, List[int]]:
        """Analyze using binary pattern matching."""
        logger.info("Running binary pattern analysis...")
        function_offsets = {}
        
        try:
            with open(file_path, 'rb') as f:
                binary_data = f.read()
            
            # Define common instruction patterns for audio processing
            patterns = {
                # Common x86 instruction patterns for audio processing
                'call_pattern': b'\xe8',  # CALL instruction
                'mov_pattern': b'\x89',   # MOV instruction
                'push_pattern': b'\x50', # PUSH instruction
                'jmp_pattern': b'\xeb',   # JMP short
                'test_pattern': b'\x85',  # TEST instruction
            }
            
            # Search for patterns and correlate with expected offsets
            for pattern_name, pattern_bytes in patterns.items():
                matches = self._find_binary_pattern(binary_data, pattern_bytes)
                
                for offset in matches:
                    # Check if this offset is close to any expected offset
                    closest_func = self._find_closest_function(offset)
                    if closest_func:
                        if closest_func not in function_offsets:
                            function_offsets[closest_func] = []
                        function_offsets[closest_func].append(offset)
            
        except Exception as e:
            logger.error(f"Error in pattern matching analysis: {e}")
        
        return function_offsets

    async def _analyze_strings(self, file_path: str) -> Dict[str, List[int]]:
        """Analyze strings in the binary for function names."""
        logger.info("Running string analysis...")
        function_offsets = {}
        
        try:
            # Try using strings command first
            strings_output = ""
            try:
                result = subprocess.run(
                    ['strings', '-t', 'x', file_path],
                    capture_output=True,
                    text=True,
                    timeout=30
                )
                
                if result.returncode == 0:
                    strings_output = result.stdout
                else:
                    logger.warning(f"strings command failed: {result.stderr}")
            except (FileNotFoundError, subprocess.SubprocessError):
                logger.info("strings command not available, using fallback method")
            
            # Fallback: manual string extraction
            if not strings_output:
                strings_output = await self._extract_strings_manually(file_path)
            
            lines = strings_output.split('\n')
            
            for line in lines:
                if not line.strip():
                    continue
                
                parts = line.strip().split(None, 1)
                if len(parts) < 2:
                    continue
                
                try:
                    offset = int(parts[0], 16)
                    string_content = parts[1]
                    
                    # Look for function names or related strings
                    for func_name in self.EXPECTED_OFFSETS.keys():
                        if self._string_matches_function(string_content, func_name):
                            if func_name not in function_offsets:
                                function_offsets[func_name] = []
                            function_offsets[func_name].append(offset)
                
                except ValueError:
                    continue
        
        except subprocess.TimeoutExpired:
            logger.error("String analysis timed out")
        except Exception as e:
            logger.error(f"Error in string analysis: {e}")
        
        return function_offsets

    async def _extract_strings_manually(self, file_path: str) -> str:
        """Manual string extraction when strings command is not available."""
        logger.info("Extracting strings manually...")
        
        try:
            with open(file_path, 'rb') as f:
                binary_data = f.read()
            
            strings_output = []
            current_string = b""
            offset = 0
            
            for i, byte in enumerate(binary_data):
                if 32 <= byte <= 126:  # Printable ASCII
                    if not current_string:
                        offset = i
                    current_string += bytes([byte])
                else:
                    if len(current_string) >= 4:  # Minimum string length
                        strings_output.append(f"{offset:x} {current_string.decode('ascii', errors='ignore')}")
                    current_string = b""
            
            # Handle string at end of file
            if len(current_string) >= 4:
                strings_output.append(f"{offset:x} {current_string.decode('ascii', errors='ignore')}")
            
            return '\n'.join(strings_output)
        
        except Exception as e:
            logger.error(f"Error in manual string extraction: {e}")
            return ""

    def _find_binary_pattern(self, data: bytes, pattern: bytes) -> List[int]:
        """Find all occurrences of a binary pattern."""
        offsets = []
        start = 0
        
        while True:
            pos = data.find(pattern, start)
            if pos == -1:
                break
            offsets.append(pos)
            start = pos + 1
        
        return offsets

    def _find_closest_function(self, offset: int, tolerance: int = 0x1000) -> Optional[str]:
        """Find the function name with closest expected offset."""
        closest_func = None
        min_distance = float('inf')
        
        for func_name, expected_offset in self.EXPECTED_OFFSETS.items():
            distance = abs(offset - expected_offset)
            if distance < min_distance and distance <= tolerance:
                min_distance = distance
                closest_func = func_name
        
        return closest_func

    def _matches_function_pattern(self, line: str, func_name: str) -> bool:
        """Check if disassembly line matches function pattern."""
        line_lower = line.lower()
        func_lower = func_name.lower()
        
        # Look for key terms in the function name
        key_terms = []
        if 'opus' in func_lower:
            key_terms.append('opus')
        if 'audio' in func_lower:
            key_terms.append('audio')
        if 'agc' in func_lower:
            key_terms.append('agc')
        if 'echo' in func_lower:
            key_terms.append('echo')
        if 'noise' in func_lower:
            key_terms.append('noise')
        if 'filter' in func_lower:
            key_terms.append('filter')
        
        return any(term in line_lower for term in key_terms)

    def _string_matches_function(self, string_content: str, func_name: str) -> bool:
        """Check if string content matches function."""
        string_lower = string_content.lower()
        func_lower = func_name.lower()
        
        # Direct match
        if func_lower in string_lower:
            return True
        
        # Partial match with key terms
        key_terms = func_lower.replace('_', ' ').split()
        return any(term in string_lower for term in key_terms if len(term) > 3)

    async def _combine_and_validate_results(
        self, 
        disasm_results: Dict[str, List[int]], 
        pattern_results: Dict[str, List[int]], 
        string_results: Dict[str, List[int]]
    ) -> List[OffsetResult]:
        """Combine results from all methods and calculate confidence scores."""
        logger.info("Combining and validating results...")
        
        combined_results = []
        all_functions = set(self.EXPECTED_OFFSETS.keys())
        
        for func_name in all_functions:
            expected_offset = self.EXPECTED_OFFSETS[func_name]
            
            # Collect all found offsets for this function
            all_offsets = []
            pattern_matches = []
            
            if func_name in disasm_results:
                all_offsets.extend(disasm_results[func_name])
                pattern_matches.append("disassembly")
            
            if func_name in pattern_results:
                all_offsets.extend(pattern_results[func_name])
                pattern_matches.append("binary_pattern")
            
            if func_name in string_results:
                all_offsets.extend(string_results[func_name])
                pattern_matches.append("string_analysis")
            
            # Find best match and calculate confidence
            best_offset, confidence = self._find_best_offset_match(
                all_offsets, expected_offset
            )
            
            # Determine validation method
            validation_method = "+".join(pattern_matches) if pattern_matches else "none"
            
            result = OffsetResult(
                function_name=func_name,
                expected_offset=expected_offset,
                found_offset=best_offset,
                confidence_score=confidence,
                validation_method=validation_method,
                pattern_matches=pattern_matches
            )
            
            combined_results.append(result)
        
        # Sort by confidence score (highest first)
        combined_results.sort(key=lambda x: x.confidence_score, reverse=True)
        
        return combined_results

    async def _combine_and_validate_results_with_progress(
        self, 
        disasm_results: Dict[str, List[int]], 
        pattern_results: Dict[str, List[int]], 
        string_results: Dict[str, List[int]],
        progress_callback: Callable
    ) -> List[OffsetResult]:
        """Combine results with progress tracking."""
        logger.info("Combining and validating results with progress...")
        
        combined_results = []
        all_functions = list(self.EXPECTED_OFFSETS.keys())
        total_functions = len(all_functions)
        
        for i, func_name in enumerate(all_functions):
            current_progress = 20 + int((i / total_functions) * 80)  # 20-100% range
            
            expected_offset = self.EXPECTED_OFFSETS[func_name]
            
            # Send progress update
            await progress_callback(current_progress, total_functions, f"Analyzing {func_name}...")
            
            # Collect all found offsets for this function
            all_offsets = []
            pattern_matches = []
            
            if func_name in disasm_results:
                all_offsets.extend(disasm_results[func_name])
                pattern_matches.append("disassembly")
            
            if func_name in pattern_results:
                all_offsets.extend(pattern_results[func_name])
                pattern_matches.append("binary_pattern")
            
            if func_name in string_results:
                all_offsets.extend(string_results[func_name])
                pattern_matches.append("string_analysis")
            
            # Find best match and calculate confidence
            best_offset, confidence = self._find_best_offset_match(
                all_offsets, expected_offset
            )
            
            # Determine validation method
            validation_method = "+".join(pattern_matches) if pattern_matches else "none"
            
            result = OffsetResult(
                function_name=func_name,
                expected_offset=expected_offset,
                found_offset=best_offset,
                confidence_score=confidence,
                validation_method=validation_method,
                pattern_matches=pattern_matches
            )
            
            combined_results.append(result)
            
            # Send progress update with result
            if best_offset is not None and confidence > 0.5:
                await progress_callback(
                    current_progress, total_functions, func_name, 
                    found=True, offset=best_offset, confidence=confidence
                )
                # Small delay to show the success animation
                await asyncio.sleep(0.1)
        
        # Sort by confidence score (highest first)
        combined_results.sort(key=lambda x: x.confidence_score, reverse=True)
        
        return combined_results

    def _find_best_offset_match(
        self, 
        found_offsets: List[int], 
        expected_offset: int
    ) -> Tuple[Optional[int], float]:
        """Find the best matching offset and calculate confidence score."""
        if not found_offsets:
            return None, 0.0
        
        # Find closest match
        best_offset = min(found_offsets, key=lambda x: abs(x - expected_offset))
        distance = abs(best_offset - expected_offset)
        
        # Calculate confidence based on distance and number of matches
        base_confidence = max(0, 1 - (distance / 0x10000))  # Closer = higher confidence
        match_bonus = min(0.3, len(found_offsets) * 0.1)    # More matches = bonus
        
        confidence = min(1.0, base_confidence + match_bonus)
        
        return best_offset, confidence

    async def generate_offset_file(self, output_path: str) -> str:
        """Generate the offset.txt file with results."""
        logger.info(f"Generating offset file: {output_path}")
        
        content = []
        content.append("=== DISCORD VOICE NODE OFFSET FINDER RESULTS ===\n")
        content.append(f"Analysis completed with {len(self.results)} functions analyzed\n")
        content.append("=" * 60 + "\n\n")
        
        # Summary statistics
        found_count = sum(1 for r in self.results if r.found_offset is not None)
        high_confidence = sum(1 for r in self.results if r.confidence_score > 0.7)
        
        content.append("SUMMARY:")
        content.append(f"  Functions analyzed: {len(self.results)}")
        content.append(f"  Functions found: {found_count}")
        content.append(f"  High confidence matches (>70%): {high_confidence}")
        content.append(f"  Success rate: {(found_count/len(self.results)*100):.1f}%\n")
        content.append("-" * 60 + "\n\n")
        
        # Detailed results
        content.append("DETAILED RESULTS:\n")
        
        for result in self.results:
            content.append(f"Function: {result.function_name}")
            content.append(f"  Expected Offset: 0x{result.expected_offset:X}")
            
            if result.found_offset is not None:
                diff = result.found_offset - result.expected_offset
                content.append(f"  Found Offset:    0x{result.found_offset:X}")
                content.append(f"  Difference:      {diff:+d} (0x{abs(diff):X})")
                content.append(f"  Confidence:      {result.confidence_score:.2%}")
            else:
                content.append(f"  Found Offset:    NOT FOUND")
                content.append(f"  Confidence:      {result.confidence_score:.2%}")
            
            content.append(f"  Validation:      {result.validation_method}")
            if result.pattern_matches:
                content.append(f"  Pattern Matches: {', '.join(result.pattern_matches)}")
            content.append("")
        
        # High confidence matches section
        high_conf_results = [r for r in self.results if r.confidence_score > 0.7 and r.found_offset is not None]
        if high_conf_results:
            content.append("\n" + "=" * 60)
            content.append("HIGH CONFIDENCE MATCHES (>70%):")
            content.append("=" * 60 + "\n")
            
            for result in high_conf_results:
                content.append(f"{result.function_name}:")
                content.append(f"  0x{result.found_offset:X} (confidence: {result.confidence_score:.2%})")
        
        # Write to file
        full_content = "\n".join(content)
        
        with open(output_path, 'w') as f:
            f.write(full_content)
        
        logger.info(f"Offset file generated successfully: {output_path}")
        return full_content