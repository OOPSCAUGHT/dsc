from fastapi import FastAPI, APIRouter, UploadFile, File, HTTPException
from fastapi.responses import FileResponse
from dotenv import load_dotenv
from starlette.middleware.cors import CORSMiddleware
from motor.motor_asyncio import AsyncIOMotorClient
import socketio
import os
import logging
from pathlib import Path
from pydantic import BaseModel, Field
from typing import List
import uuid
from datetime import datetime
import tempfile
import aiofiles
import asyncio

from offset_finder import DiscordVoiceOffsetFinder

ROOT_DIR = Path(__file__).parent
load_dotenv(ROOT_DIR / '.env')

# MongoDB connection
mongo_url = os.environ['MONGO_URL']
client = AsyncIOMotorClient(mongo_url)
db = client[os.environ['DB_NAME']]

# Create Socket.IO server
sio = socketio.AsyncServer(
    async_mode='asgi',
    cors_allowed_origins="*",
    logger=True,
    engineio_logger=True
)

# Create the main app without a prefix
app = FastAPI()

# Create a router with the /api prefix
api_router = APIRouter(prefix="/api")

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# Define Models
class StatusCheck(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    client_name: str
    timestamp: datetime = Field(default_factory=datetime.utcnow)

class StatusCheckCreate(BaseModel):
    client_name: str

class AnalysisResult(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    filename: str
    total_functions: int
    functions_found: int
    high_confidence_matches: int
    success_rate: float
    analysis_timestamp: datetime = Field(default_factory=datetime.utcnow)

# Initialize offset finder
offset_finder = DiscordVoiceOffsetFinder()

# WebSocket event handlers
@sio.event
async def connect(sid, environ, auth):
    logger.info(f"Client connected: {sid}")
    await sio.emit('connected', {'message': 'Connected to Discord Voice Node Offset Finder'}, room=sid)

@sio.event
async def disconnect(sid):
    logger.info(f"Client disconnected: {sid}")

# Progress callback for real-time updates
async def progress_callback(sid: str, current: int, total: int, function_name: str, found: bool = False, offset: int = None, confidence: float = 0.0):
    """Send progress updates to connected client"""
    progress_data = {
        'current': current,
        'total': total,
        'percentage': round((current / total) * 100, 1),
        'function_name': function_name,
        'found': found,
        'offset': f"0x{offset:X}" if offset else None,
        'confidence': round(confidence * 100, 1)
    }
    await sio.emit('analysis_progress', progress_data, room=sid)

# Add your routes to the router instead of directly to app
@api_router.get("/")
async def root():
    return {"message": "Discord Voice Node Offset Finder API"}

@api_router.post("/status", response_model=StatusCheck)
async def create_status_check(input: StatusCheckCreate):
    status_dict = input.dict()
    status_obj = StatusCheck(**status_dict)
    _ = await db.status_checks.insert_one(status_obj.dict())
    return status_obj

@api_router.get("/status", response_model=List[StatusCheck])
async def get_status_checks():
    status_checks = await db.status_checks.find().to_list(1000)
    return [StatusCheck(**status_check) for status_check in status_checks]

@api_router.post("/analyze/{session_id}")
async def analyze_discord_voice_node_with_progress(session_id: str, file: UploadFile = File(...)):
    """
    Analyze a discord_voice.node file with real-time progress updates via WebSocket.
    """
    
    # Validate file
    if not file.filename.endswith('.node'):
        raise HTTPException(
            status_code=400, 
            detail="File must be a .node file"
        )
    
    # Check file size (limit to 100MB)
    if file.size and file.size > 100 * 1024 * 1024:
        raise HTTPException(
            status_code=400,
            detail="File too large. Maximum size is 100MB"
        )
    
    # Create temporary file
    temp_dir = tempfile.mkdtemp()
    temp_file_path = os.path.join(temp_dir, file.filename)
    
    try:
        # Save uploaded file
        async with aiofiles.open(temp_file_path, 'wb') as f:
            content = await file.read()
            await f.write(content)
        
        # Validate file content
        if len(content) == 0:
            raise HTTPException(
                status_code=400,
                detail="Uploaded file is empty"
            )
        
        logger.info(f"Analyzing file: {file.filename} ({len(content)} bytes)")
        
        # Create progress callback for this session
        async def session_progress_callback(current, total, function_name, found=False, offset=None, confidence=0.0):
            await progress_callback(session_id, current, total, function_name, found, offset, confidence)
        
        # Perform analysis with progress tracking
        try:
            results = await offset_finder.analyze_file_with_progress(temp_file_path, session_progress_callback)
        except Exception as analysis_error:
            logger.error(f"Analysis failed: {str(analysis_error)}")
            await sio.emit('analysis_error', {'error': str(analysis_error)}, room=session_id)
            raise HTTPException(
                status_code=500, 
                detail=f"Binary analysis failed: {str(analysis_error)}"
            )
        
        # Generate offset.txt file
        output_dir = Path("/app/output")
        output_dir.mkdir(exist_ok=True)
        
        offset_file_path = output_dir / "offset.txt"
        try:
            await offset_finder.generate_offset_file(str(offset_file_path))
        except Exception as file_error:
            logger.error(f"File generation failed: {str(file_error)}")
            raise HTTPException(
                status_code=500,
                detail=f"Result file generation failed: {str(file_error)}"
            )
        
        # Calculate statistics
        found_count = sum(1 for r in results if r.found_offset is not None)
        high_confidence = sum(1 for r in results if r.confidence_score > 0.7)
        success_rate = (found_count / len(results) * 100) if results else 0
        
        # Create analysis result
        analysis_result = AnalysisResult(
            filename=file.filename,
            total_functions=len(results),
            functions_found=found_count,
            high_confidence_matches=high_confidence,
            success_rate=success_rate
        )
        
        # Save to database
        try:
            await db.analysis_results.insert_one(analysis_result.dict())
        except Exception as db_error:
            logger.warning(f"Database save failed: {str(db_error)}")
        
        # Send completion notification
        await sio.emit('analysis_complete', analysis_result.dict(), room=session_id)
        
        logger.info(f"Analysis complete: {found_count}/{len(results)} functions found")
        
        return analysis_result
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Unexpected error analyzing file: {str(e)}")
        await sio.emit('analysis_error', {'error': str(e)}, room=session_id)
        raise HTTPException(status_code=500, detail=f"Analysis failed: {str(e)}")
    
    finally:
        # Cleanup temporary file
        try:
            if os.path.exists(temp_file_path):
                os.remove(temp_file_path)
            if os.path.exists(temp_dir):
                os.rmdir(temp_dir)
        except Exception as cleanup_error:
            logger.warning(f"Cleanup failed: {str(cleanup_error)}")

@api_router.post("/analyze", response_model=AnalysisResult)
async def analyze_discord_voice_node(file: UploadFile = File(...)):
    """
    Analyze a discord_voice.node file to find function offsets (legacy endpoint without progress).
    Returns analysis results and generates offset.txt file.
    """
    
    # Validate file
    if not file.filename.endswith('.node'):
        raise HTTPException(
            status_code=400, 
            detail="File must be a .node file"
        )
    
    # Check file size (limit to 100MB)
    if file.size and file.size > 100 * 1024 * 1024:
        raise HTTPException(
            status_code=400,
            detail="File too large. Maximum size is 100MB"
        )
    
    # Create temporary file
    temp_dir = tempfile.mkdtemp()
    temp_file_path = os.path.join(temp_dir, file.filename)
    
    try:
        # Save uploaded file
        async with aiofiles.open(temp_file_path, 'wb') as f:
            content = await file.read()
            await f.write(content)
        
        # Validate file content
        if len(content) == 0:
            raise HTTPException(
                status_code=400,
                detail="Uploaded file is empty"
            )
        
        logger.info(f"Analyzing file: {file.filename} ({len(content)} bytes)")
        
        # Perform analysis
        try:
            results = await offset_finder.analyze_file(temp_file_path)
        except Exception as analysis_error:
            logger.error(f"Analysis failed: {str(analysis_error)}")
            raise HTTPException(
                status_code=500, 
                detail=f"Binary analysis failed: {str(analysis_error)}"
            )
        
        # Generate offset.txt file
        output_dir = Path("/app/output")
        output_dir.mkdir(exist_ok=True)
        
        offset_file_path = output_dir / "offset.txt"
        try:
            await offset_finder.generate_offset_file(str(offset_file_path))
        except Exception as file_error:
            logger.error(f"File generation failed: {str(file_error)}")
            raise HTTPException(
                status_code=500,
                detail=f"Result file generation failed: {str(file_error)}"
            )
        
        # Calculate statistics
        found_count = sum(1 for r in results if r.found_offset is not None)
        high_confidence = sum(1 for r in results if r.confidence_score > 0.7)
        success_rate = (found_count / len(results) * 100) if results else 0
        
        # Create analysis result
        analysis_result = AnalysisResult(
            filename=file.filename,
            total_functions=len(results),
            functions_found=found_count,
            high_confidence_matches=high_confidence,
            success_rate=success_rate
        )
        
        # Save to database
        try:
            await db.analysis_results.insert_one(analysis_result.dict())
        except Exception as db_error:
            logger.warning(f"Database save failed: {str(db_error)}")
            # Don't fail the whole request for database issues
        
        logger.info(f"Analysis complete: {found_count}/{len(results)} functions found")
        
        return analysis_result
        
    except HTTPException:
        # Re-raise HTTP exceptions as-is
        raise
    except Exception as e:
        logger.error(f"Unexpected error analyzing file: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Analysis failed: {str(e)}")
    
    finally:
        # Cleanup temporary file
        try:
            if os.path.exists(temp_file_path):
                os.remove(temp_file_path)
            if os.path.exists(temp_dir):
                os.rmdir(temp_dir)
        except Exception as cleanup_error:
            logger.warning(f"Cleanup failed: {str(cleanup_error)}")

@api_router.get("/download-results")
async def download_offset_results():
    """
    Download the generated offset.txt file.
    """
    offset_file_path = Path("/app/output/offset.txt")
    
    if not offset_file_path.exists():
        raise HTTPException(
            status_code=404, 
            detail="No analysis results found. Please run an analysis first."
        )
    
    return FileResponse(
        path=str(offset_file_path),
        filename="offset.txt",
        media_type="text/plain"
    )

@api_router.get("/analysis-history", response_model=List[AnalysisResult])
async def get_analysis_history():
    """
    Get history of previous analyses.
    """
    analyses = await db.analysis_results.find().sort("analysis_timestamp", -1).to_list(50)
    return [AnalysisResult(**analysis) for analysis in analyses]

# Include the router in the main app
app.include_router(api_router)

app.add_middleware(
    CORSMiddleware,
    allow_credentials=True,
    allow_origins=os.environ.get('CORS_ORIGINS', '*').split(','),
    allow_methods=["*"],
    allow_headers=["*"],
)

# Mount Socket.IO
socket_app = socketio.ASGIApp(sio, app)

@app.on_event("shutdown")
async def shutdown_db_client():
    client.close()

# Replace the app with socket_app for the main application
app = socket_app